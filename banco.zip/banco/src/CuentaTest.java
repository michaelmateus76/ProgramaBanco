import org.junit.Test;

import static org.junit.Assert.*;

public class CuentaTest{

    @Test
    public void testsConsultarSaldo(){
        int numC = 1010;
        int ide = 5432;
        double monto = 78292.2;
        String tipo = "ahorros";
        String fecha="22/08/2020";
        Cuenta cu = new Cuenta(numC,ide,monto,tipo,fecha);

        double m = cu.consultarSaldo(numC,ide);
        assertEquals(78292.2,m,2);
    }
}