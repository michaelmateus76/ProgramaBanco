import org.junit.Test;

import static org.junit.Assert.*;

public class TarjetaTest {
    @Test
    public void testsRealizarCompra(){
        int ide = 1010;
        int cod = 5432;
        double cupo = 78292.2;
        double valorCuota = 32313;
        double saldo = 423221.123;
        String fecha="22/08/2023";
        Tarjeta ta = new Tarjeta(ide,cod,fecha,cupo,valorCuota,saldo);

        double rc = ta.realizarCompra(1,50000,1);
        assertEquals(28292,rc,2);
    }

    @Test
    public void testsConsultarSaldo(){
        int ide = 1010;
        int cod = 5432;
        double cupo = 78292.2;
        double valorCuota = 32313;
        double saldo = 423221.123;
        String fecha="22/08/2023";
        Tarjeta ta = new Tarjeta(ide,cod,fecha,cupo,valorCuota,saldo);

        double rc = ta.consultarSaldo();
        assertEquals(saldo,rc,2);
    }

    @Test
    public void testsConsultarCupo(){
        int ide = 1010;
        int cod = 5432;
        double cupo = 78292.2;
        double valorCuota = 32313;
        double saldo = 423221.123;
        String fecha="22/08/2023";
        Tarjeta ta = new Tarjeta(ide,cod,fecha,cupo,valorCuota,saldo);

        double rc = ta.consultarCupo();
        assertEquals(cupo,rc,2);
    }

    @Test
    public void testsPagarTarjeta(){
        int ide = 1010;
        int cod = 5432;
        double cupo = 78292.2;
        double valorCuota = 32313;
        double saldo = 423221.123;
        String fecha="22/08/2023";
        Tarjeta ta = new Tarjeta(ide,cod,fecha,cupo,valorCuota,saldo);

        boolean rc = ta.pagarTarjeta(32314);
        assertEquals(true,rc);
    }
}