public class Cuenta {

    int numCuenta;
    int identificacion;
    double monto;
    String tipo;
    String fechaApertura;

    public Cuenta(int numCuenta, int identificacion, double monto, String tipo, String fechaApertura) {
        this.numCuenta = numCuenta;
        this.identificacion = identificacion;
        this.monto = monto;
        this.tipo = tipo;
        this.fechaApertura = fechaApertura;
    }

    public double consultarSaldo(int numero,int identificacion){
        return monto;
    }
}
