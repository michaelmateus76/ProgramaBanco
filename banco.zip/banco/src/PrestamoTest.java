import org.junit.Test;

import static org.junit.Assert.*;

public class PrestamoTest {

    @Test
    public void testsConsultarSaldo(){
        int ide = 1010;
        double valorPrestado = 7238292.2;
        double tiempo = 3;
        double valorCuotas = 1090238.32;
        double interes = 3.6;
        String fecha = "22/08/2020";
        Prestamo pr = new Prestamo(tiempo,valorCuotas,fecha,ide,interes);

        boolean pre = pr.pedirPrestamo(valorPrestado);
        assertEquals(true,pre);
    }

    @Test
    public void testsPagarCuota(){
        int ide = 1010;
        double tiempo = 3;
        double valorCuotas = 1090238.32;
        double interes = 3.6;
        String fecha = "22/08/2020";
        Prestamo pr = new Prestamo(tiempo,valorCuotas,fecha,ide,interes);

        boolean pre = pr.pagarCuota(ide,1100000);
        assertEquals(true,pre);
    }
}