public class Transaccion {

    int identificacion;
    int numCuenta;
    double monto;

    public Transaccion(int identificacion, int numCuenta, double monto) {
        this.identificacion = identificacion;
        this.numCuenta = numCuenta;
        this.monto = monto;
    }

    public double consignar(int id, int numC, double valor){
        this.monto = monto + valor;
        return monto;
    }

    public double retirar(int id, int numC, double valor){
        this.monto = monto - valor;
        return monto;
    }

    public double transferir(int id, int numC, double valor){
        this.monto = monto - valor;
        return monto;
    }
}
