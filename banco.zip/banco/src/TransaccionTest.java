import org.junit.Test;

import static org.junit.Assert.*;

public class TransaccionTest {
    @Test
    public void testsConsignar(){
        int numC = 1010;
        int ide = 5432;
        double monto = 78292.2;
        Transaccion tr = new Transaccion(ide,numC,monto);

        double c = tr.consignar(ide,numC,30650.98);
        assertEquals(108943.18,c,0);
    }

    @Test
    public void testsRetirar(){
        int numC = 7878;
        int ide = 3232;
        double monto = 445642.2;
        Transaccion tr = new Transaccion(ide,numC,monto);

        double c = tr.retirar(ide,numC,350000);
        assertEquals(95642.2,c,2);
    }

    @Test
    public void testsTransferir(){
        int numC = 91212;
        int ide = 2324;
        double monto = 33892.7;
        Transaccion tr = new Transaccion(ide,numC,monto);

        double c = tr.transferir(ide,numC,30650.98);
        assertEquals(3241.72,c,2);
    }
}