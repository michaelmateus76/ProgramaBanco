public class Tarjeta {

    int codigo;
    int identificacion;
    String fechaVencimiento;

    //Crédito tipo 1
    double cupo;
    double valorCuota;

    //Debito tipo 2
    double saldo;

    public Tarjeta(int codigo, int identificacion, String fechaVencimiento, double cupo, double valorCuota, double saldo) {
        this.codigo = codigo;
        this.identificacion = identificacion;
        this.fechaVencimiento = fechaVencimiento;
        this.cupo = cupo;
        this.valorCuota = valorCuota;
        this.saldo = saldo;
    }

    public double realizarCompra(int num, double valor, int tipo){
        if(tipo==1){
            this.cupo = cupo - valor;
            return cupo;
        }else{
            this.saldo = saldo - valor;
            return valor;
        }
    }

    public double consultarSaldo(){
        return saldo;
    }

    public double consultarCupo(){
        return cupo;
    }

    public boolean pagarTarjeta(double valor){
        if(valor>=valorCuota){
            return true;
        }else{
            return false;
        }

    }

}
