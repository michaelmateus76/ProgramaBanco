import org.junit.Test;

import static org.junit.Assert.*;

public class ClienteTest {

    @Test
    public void testsConsultarProductos(){
        int ide = 54323;
        String nombre = "Michael";
        String apellido="Pinilla";
        String tel = "30943242";
        Cliente cli = new Cliente(ide,nombre,apellido,tel);

        String pro = cli.consultarProductos(ide);
        assertEquals("Tarjeta debito",pro);
    }
}