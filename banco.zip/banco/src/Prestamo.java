public class Prestamo {

    double valorPrestamo = 0;
    double tiempo;
    double valorCuotas;
    String fechaInicio;
    int identificacion;
    double interes;

    public Prestamo(double tiempo, double valorCuotas, String fechaInicio, int identificacion, double interes) {
        this.tiempo = tiempo;
        this.valorCuotas = valorCuotas;
        this.fechaInicio = fechaInicio;
        this.identificacion = identificacion;
        this.interes = interes;
    }

    public boolean pedirPrestamo(double valor){
        valorPrestamo = valor;
        if (valorPrestamo == valor){
            return true;
        }else{
            return false;
        }
    }

    public boolean pagarCuota(int ide, double valor){
        if(valor>=valorCuotas){
            return true;
        }else{
            return false;
        }
    }
}
