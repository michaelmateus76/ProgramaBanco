public class Cliente {

    int identificacion;
    String nombre;
    String apellido;
    String telefono;

    public Cliente(int identificacion, String nombre, String apellido, String telefono) {
        this.identificacion = identificacion;
        this.nombre = nombre;
        this.apellido = apellido;
        this.telefono = telefono;
    }

    public String consultarProductos(int identificacion){
        String producto = "Tarjeta debito";
        return producto;
    }
}
